package pl.edu.uwm.po.lab1;

public class Start {
    public static void zad1 ()
    {
        System.out.println(31+29+31);
    }
    public static void zad2 ()
    {
        System.out.println(1+2+3+4+5+6+7+8+9+10);
    }
    public static void zad3()
    {
        System.out.println(1*2*3*4*5*6*7*8*9*10);
    }
    public static void zad4()
    {
        double x=1000;
        x=x+x*0.06;
        System.out.println(x);
        x=x+x*0.06;
        System.out.println(x);
        x=x+x*0.06;
        System.out.println(x);
    }
    public static void zad5()
    {
        System.out.println("+------+");
        System.out.println("| JAVA |");
        System.out.println("+------+");
    }
    public static void zad69()
    {
        System.out.println("  /\\_/\\         --------");
        System.out.println(" ( - - )      /  Kochac  \\");
        System.out.println(" (  _  )    <     Disa    |");
        System.out.println("  | | |       \\          /");
        System.out.println(" (__|__)        --------");
    }
    public static void zad10()
    {
        System.out.println(" Colony s4. ");
        System.out.println(" Interstellar ");
        System.out.println(" The Avengers ");
    }
    public static void zad11()
    {
        System.out.println(" Pytano kaznodzieje: \"Czemu to, prałacie, ");
        System.out.println(" Nie tak sami żywiecie, jako nauczacie?\" ");
        System.out.println(" (A miał doma kucharkę.) I rzecze: \"Mój panie, ");
        System.out.println(" Kazaniu się nie dziwuj, bo mam pięćset na nie; ");
        System.out.println(" A nie wziąłbych tysiąca, mogę to rzec śmiele, ");
        System.out.println(" Bych tak miał czynić, jako nauczam w kościele.\" ");

    }
    public static void main(String[] args)
    {
        zad11();
    }
}
